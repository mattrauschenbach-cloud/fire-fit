export default function Home(){
  return (
    <section className='space-y-6'>
      <h1 className='text-3xl font-bold'>Station 1 Fit Garfield Heights</h1>
      <p className='text-slate-600'>Weekly & Monthly challenges. Mentor tools. Standards for everyone.</p>
    </section>
  )
}
